# redpillmagazinepwa

I SEGUENTI LINK RIMANDANO AD ALTRETTANTI TUTORIAL SU COME CREARE UNA PWA PARTENDO DAL NOSTRO SITO JOOMLA

https://www.joomla.it/blog/8929-trasformiamo-il-nostro-sito-joomla-in-una-progressive-web-application.html

https://www.pixed.it/pixed-blog/joomla/118-come-trasformare-il-proprio-sito-joomla-in-una-pwa-progressive-web-app.html

https://it.semrush.com/blog/cose-una-pwa-progressive-web-app/

https://web.dev/install-criteria/

https://web.dev/customize-install/

Le procedure di customizzazione del codice e le procedure di collaudo dello stesso sono le medesime per tutti e tre i tutorial.

TUTTI I LINK PRESENTI IN QUESTO REPOSITORY RIMANDANO ALLE FONTI ORIGINALI DALLE QUALI HO TRATTO IL CODICE DELLA PWA; PERTANTO QUESTO LAVORO NON E'FARINA DEL MIO SACCO :P
